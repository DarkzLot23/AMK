AMK Vault Sync Agent - Installation Instructions

1. Unzip this archive anywhere on your system.
2. Double-click 'vault_install.bat'.
3. This installs the sync agent to your Startup folder.
4. Your AMK_LiveVault folder will appear on Desktop.
5. Data will auto-sync from this environment (or test payload).
