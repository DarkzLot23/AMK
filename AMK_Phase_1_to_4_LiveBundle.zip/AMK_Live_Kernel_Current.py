# Combined kernel snapshot (Phases 1–4)
# Updated memory engine, role logic, routing