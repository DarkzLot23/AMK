#!/bin/bash
python3 amk.py
